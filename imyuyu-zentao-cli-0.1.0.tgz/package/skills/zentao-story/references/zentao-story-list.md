# story list

列出某个产品下的需求列表。

## Command
```bash
zentao story list --product <id> [--status <status>] [--project <id>]
```

## Options

| Option | Required | Description |
|--------|----------|-------------|
| `--product` | Yes | 产品 ID |
| `--status` | No | 按状态筛选：draft / active / closed / changed |
| `--project` | No | 按项目 ID 筛选 |

## Examples

```bash
# List all stories for product 1
zentao story list --product 1

# List active stories only
zentao story list --product 1 --status active

# List stories in a specific project
zentao story list --product 1 --project 1
```

## Output Fields

| Field | Type | Description |
|-------|------|-------------|
| id | u64 | 需求 ID |
| title | string | 需求标题 |
| product | u64 | 产品 ID |
| status | string | 需求状态：draft / active / closed / changed |
| pri | u8 | 优先级：0-5 |
| category | string | 需求类别（可选）：feature / requirement / bug / improvement |
| stage | string | 当前阶段（可选）：wait / plan / developed / 测试中 / released / closed |
| module | u64 | 所属模块 ID（可选） |
| assigned_to | string | 指派人（可选） |
| estimate | f64 | 预估工时（小时）（可选） |
| version | u64 | 版本号（可选） |
