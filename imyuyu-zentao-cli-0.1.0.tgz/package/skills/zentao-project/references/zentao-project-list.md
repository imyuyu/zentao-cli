# project list

列出所有项目。

## Command
```bash
zentao project list
```

## Options

| Option | Required | Description |
|--------|----------|-------------|
| `--status` | No | Filter by status: wait, doing, suspended, closed |

## Examples

```bash
# List all projects
zentao project list

# List projects with specific status
zentao project list --status doing
```

## Output Fields

| Field | Type | Description |
|-------|------|-------------|
| id | u64 | Project ID |
| name | string | Project name |
| code | string | Project code |
| status | string | Project status |
| desc | string | Project description |
